from flet import(
    Column,
    Page,
    IconButton,
    icons
)

import pages

paginas = []
page = Page

addit = ""

#extrato_page = pages.extrato.main.tela
#categorias_page = pages.categorias.main.tela
#perfil_page = pages.perfil.main.tela

#paginas.append(extrato_page)
#paginas.append(categorias_page)
#paginas.append(perfil_page)

tela = "00"

def NavigationChange(e):
    index = e.control.selected_index
    #count = 0
    global tela
    for pag in paginas:
        if pag[1] == index and pag[2] == int(tela[1]):
            try:
                pag[3]()
            except:
                pass
            pag[0].visible = True 
        else:
            pag[0].visible = False

        print(f"{tela} // {pag[1]}{pag[2]}")
        #count += 1
    tela = f"{index}{tela[1]}"
    print(tela)
    page.update()

def BackScreen(e):
    global tela
    newScreen = int(tela[1])-1

    if newScreen == 0:
        page.appbar.leading = None
        page.navigation_bar.visible = True

    for pag in paginas:
        if pag[2] == newScreen and pag[1] == int(tela[0]):
            pag[3]()
            pag[0].visible = True
        else:
            pag[0].visible = False

    tela = f"{tela[0]}{newScreen}"
    page.update()
    print(tela)

def ChangeScreen(screen, e):
    global addit
    global tela
    tela = screen
    page.appbar.leading = IconButton(
        icon = icons.ARROW_BACK,
        on_click = BackScreen,
    )
    page.navigation_bar.visible = False

    addit = e.control.key

    for pag in paginas:
        if pag[1] == int(tela[0]) and pag[2] == int(tela[1]):
            pag[3]()
            pag[0].visible = True
        else:
            pag[0].visible = False
        #count += 1
    
    print("Porra")
    page.update()

    print(tela)

def refresh():
    page.update()
