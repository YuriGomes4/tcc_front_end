# tcc_front_end
 
```
flet publish main.py --web-renderer html

python3 -m http.server --directory dist
```