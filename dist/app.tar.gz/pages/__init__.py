#from . import categorias
from . import central
#from . import dispositivos
#from . import configuracoes
#from . import login